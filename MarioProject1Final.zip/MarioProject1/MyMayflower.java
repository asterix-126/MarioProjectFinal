
import mayflower.*;
public class MyMayflower extends Mayflower
{
    public MyMayflower()
    {
        super("Project1", 950, 720);
    }
    public void init()
    {
        Mayflower.setFullScreen(false);
        Mayflower.setWorld(new Title());
    }
}
