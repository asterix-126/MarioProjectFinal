import mayflower.*;
public class Level2 extends World
{
    public Level2()
    {
        setBackground("characters/backgrounds/LevelOneBackground.jpg");
        String[][] tiles = new String[9][12];
    }
    public void act()
    {
        
    }
}
