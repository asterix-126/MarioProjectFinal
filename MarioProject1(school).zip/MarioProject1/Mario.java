import mayflower.*;
public class Mario extends MoveableAnimatedActor
{
    private Animation idleRight, idleLeft,  climb, walkRight, walkLeft, fallRight, fallLeft;
    private int lives, score, level;
    public Mario()
    {
        String[] idleFiles = new String[4];
        for (int i = 0; i<idleFiles.length; i++)
        {
           idleFiles[i] = new String("characters/mario/idle(" + (i) + ").png"); 
        }
        idleRight = new Animation(50, idleFiles);
        
        String[] walkFiles = new String[4];
        for (int i = 0; i<walkFiles.length; i++)
        {
           walkFiles[i] = new String("characters/mario/walk(" + (i) + ").png"); 
        }
        walkRight = new Animation(50, walkFiles);
        
        String[] fallFiles = new String[1];
        for (int i = 0; i<fallFiles.length; i++)
        {
           fallFiles[i] = new String("characters/mario/jump(" + (i) + ").png"); 
        }
        fallRight = new Animation(50, fallFiles);
        
        walkLeft = new Animation(50, walkFiles);
        walkLeft.mirrorHorizontally();
        
        idleLeft = new Animation(50, idleFiles);
        idleLeft.mirrorHorizontally();
        
        fallLeft = new Animation(50, fallFiles);
        fallLeft.mirrorHorizontally();

        //walkRight.scale(32, 32);
        //walkLeft.scale(32, 32);
        //idleRight.scale(32, 32);
        //idleLeft.scale(32, 32);
        //jumpRight.scale(32,32);
        //jumpLeft.scale(32,32);
        //climb.scale(32, 32);
        
        setWalkRightAnimation(walkRight);
        setWalkLeftAnimation(walkLeft);
        setIdleRightAnimation(idleRight);
        setIdleLeftAnimation(idleLeft);
        setFallRightAnimation(fallRight);
        setFallLeftAnimation(fallLeft);
        setClimbAnimation(climb);
        
        setAnimation(idleRight);
        lives = 3;
        level = 1;
    }
    public void setLevel(int num)
    {
        level = num;
    }
    public void increaseScore(int num)
    {
        score += num;
    }
    public void decreaseLives(int num)
    {
        lives -= num;
    }
    public int getScore()
    {
        return score;
    }
    public int getLives()
    {
        return lives;
    }
    public void updateText()
    {
        World w = getWorld();
        w.removeText(10,30);
        w.showText("Coins: " + score + " Lives: " + lives, 10, 30, Color.BLACK);
    }
    public void act()
    {
        super.act();
        updateText();
        
        if(isTouching(pipe.class))
        {
            if((level == 1) && (score >= 3))
            {
                Mayflower.setWorld(new Level2());
            }
        }
    }
}
