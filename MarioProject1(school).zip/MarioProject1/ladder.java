import mayflower.*;
public class ladder extends Actor
{

    /**
     * Constructor for objects of class ladder
     */
    public ladder()
    {
        setImage("characters/items/ladder.png");
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void act()
    {
        
    }
}
