import mayflower.*;
public class bricks extends Actor
{
    public bricks()
    {
        setImage("characters/floor/Bricks.png");
    }
    public void act()
    {

    }
}
