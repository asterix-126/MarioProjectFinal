import mayflower.*;
import java.util.*;
public class Level1 extends World
{
    private ladder Sliddy;
    private Mario mario;
    private pipe pipe; 

    public Level1()
    {
        setBackground("characters/backgrounds/LevelOneBackground.jpg");
        String[][] tiles = new String[9][12]; //try 7 by 4 later
        buildLevel1(tiles);
        Sliddy = new ladder();
        mario = new Mario();
        pipe = new pipe();
        addObject(mario, 100,100);
        addObject(pipe, 800,500);
        addObject(Sliddy, 500, 500);
        showText("Coins needed: 3", 10, 60, Color.BLACK);
        Mayflower.showBounds(true);

        
    }
    public void buildLevel1(String[][] tiles)
    {
        for( int i = 0; i < tiles.length; i++)
        {
            for( int j = 0; j < tiles[i].length; j++)
            {
                tiles[i][j] = "";
            }
        }
        for(int j = 0; j < tiles[8].length; j++)
        {
            tiles[8][j] = "ground";
        }
        for(int c = 0; c < 5; c++)
        {
            int rand = (int)(Math.random() * 11);
            tiles[5][rand] = "coin";
        }
         for(int r = 0; r < tiles.length; r++)
        {
            for( int c = 0; c < tiles[r].length; c++)
            {
                if (tiles[r][c].equals("ground"))
                    {
                        addObject(new bricks(), c*84, r*80);
                    }
                if (tiles[r][c].equals("coin"))
                    {
                        addObject(new coin(), c*84, r*80);
                    }
            }
        }
    }
    
    public void act()
    {
        
    }

}
